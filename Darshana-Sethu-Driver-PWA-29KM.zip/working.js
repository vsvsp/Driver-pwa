/* Darshana Sethu Driver - working.js */
"use strict";

const SETHU_DRIVER_VERSION="1.2.0";

function dsGet(k,d=""){const v=localStorage.getItem(k);return v===null?d:v}
function dsSet(k,v){localStorage.setItem(k,String(v))}
function dsPhone(v){return String(v||"").replace(/\D/g,"").slice(0,10)}
function dsPhoneOK(v){return /^\d{10}$/.test(dsPhone(v))}
function dsPinOK(v){return /^\d{4}$/.test(String(v||""))}

function saveDriverProfile(name,phone){
  name=String(name||"").trim(); phone=dsPhone(phone);
  if(!name||!dsPhoneOK(phone)) return false;
  dsSet("driverName",name); dsSet("driverPhone",phone);
  dsSet("driverProfileSetupComplete","yes"); return true;
}
function setDriverPin(pin,confirmPin){
  if(!dsPinOK(pin)||String(pin)!==String(confirmPin)) return false;
  dsSet("driverLoginPin",pin); dsSet("driverProfileSetupComplete","yes"); return true;
}
function loginDriver(phone,pin){
  phone=dsPhone(phone);
  if(!dsPhoneOK(phone)||!dsPinOK(pin)) return false;
  if(phone!==dsPhone(dsGet("driverPhone"))||String(pin)!==dsGet("driverLoginPin")) return false;
  dsSet("driverLoggedIn","yes"); return true;
}
function getCurrentRide(){try{return JSON.parse(dsGet("driverCurrentRide","null"))}catch(e){return null}}
function setCurrentRide(ride){dsSet("driverCurrentRide",JSON.stringify(ride))}
function updateRideStatus(status){
  const ride=getCurrentRide(); if(!ride)return null;
  ride.status=status; ride[status+"At"]=new Date().toISOString(); setCurrentRide(ride); return ride;
}
function calculateEarnings(fare,commissionRate=.083){
  fare=Number(fare||0); const commission=Math.round(fare*Number(commissionRate));
  return {fare,commission,driverEarning:Math.max(0,fare-commission)};
}
window.DarshanaSethuDriver={version:SETHU_DRIVER_VERSION,profile:{save:saveDriverProfile,setPin:setDriverPin,login:loginDriver},ride:{get:getCurrentRide,set:setCurrentRide,status:updateRideStatus},earnings:{calculate:calculateEarnings}};
