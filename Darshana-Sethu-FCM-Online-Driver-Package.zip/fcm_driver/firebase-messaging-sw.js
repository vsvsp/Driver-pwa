/* Darshana Sethu Driver Partner - Firebase Cloud Messaging service worker */
importScripts('https://www.gstatic.com/firebasejs/12.17.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/12.17.1/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyCKKThIcHKI8jFvOmfXgQZ-UKXWNCiha_U",
  authDomain: "darshana-sethu-cab.firebaseapp.com",
  projectId: "darshana-sethu-cab",
  storageBucket: "darshana-sethu-cab.firebasestorage.app",
  messagingSenderId: "753735533400",
  appId: "1:753735533400:web:dd314c6e8b61d2f1b09b2d",
  measurementId: "G-E366CXE9LT"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload){
  const title = (payload.notification && payload.notification.title) || (payload.data && payload.data.title) || 'Darshana Sethu – New Ride';
  const body = (payload.notification && payload.notification.body) || (payload.data && payload.data.body) || 'New ride request available';
  self.registration.showNotification(title, {
    body,
    icon: './icon-192.png',
    badge: './icon-192.png',
    data: payload.data || {},
    vibrate: [300,100,300,100,500]
  });
});

self.addEventListener('notificationclick', function(event){
  event.notification.close();
  const url = new URL('./', self.location.origin).href;
  event.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(function(list){
    for(const c of list){ if('focus' in c){ c.focus(); return c; } }
    if(clients.openWindow) return clients.openWindow(url);
  }));
});
