const {onDocumentCreated} = require('firebase-functions/v2/firestore');
const {initializeApp} = require('firebase-admin/app');
const {getFirestore} = require('firebase-admin/firestore');
const {getMessaging} = require('firebase-admin/messaging');

initializeApp();
const db = getFirestore();

function bookingText(b){
  const pickup=b.pickup || b.pickupLocation || b.pickupAddress || 'Pickup';
  const drop=b.destination || b.drop || b.dropLocation || b.dropAddress || 'Destination';
  return `${pickup} → ${drop}`;
}

exports.dispatchNewRideToOnlineDrivers = onDocumentCreated('bookings/{bookingId}', async (event) => {
  const snap=event.data;
  if(!snap) return;
  const b=snap.data() || {};
  const status=String(b.status || b.rideStatus || 'Pending').toLowerCase();
  if(['accepted','assigned','started','ongoing','completed','cancelled','canceled'].includes(status)) return;

  const driversSnap=await db.collection('drivers')
    .where('isOnline','==',true)
    .where('rideEligible','==',true)
    .get();

  const tokens=[];
  const tokenOwners=[];
  driversSnap.forEach(d=>{
    const x=d.data() || {};
    const approved=String(x.approvalStatus || x.status || 'Approved').toLowerCase()==='approved';
    if(!approved) return;
    const map=x.fcmTokens && typeof x.fcmTokens==='object' ? Object.keys(x.fcmTokens).filter(k=>x.fcmTokens[k]) : [];
    if(x.fcmToken) map.push(x.fcmToken);
    for(const t of [...new Set(map)]){ tokens.push(t); tokenOwners.push({ref:d.ref,token:t}); }
  });
  const unique=[...new Set(tokens)];
  if(!unique.length) return;

  const message={
    tokens:unique,
    notification:{title:'Darshana Sethu – New Ride',body:bookingText(b)},
    data:{type:'new_ride',bookingId:event.params.bookingId,pickup:String(b.pickup || b.pickupLocation || ''),drop:String(b.destination || b.drop || '')},
    android:{priority:'high',notification:{channelId:'ride_requests',sound:'default'}},
    webpush:{headers:{Urgency:'high'},notification:{title:'Darshana Sethu – New Ride',body:bookingText(b),requireInteraction:true}}
  };
  const response=await getMessaging().sendEachForMulticast(message);

  const invalid=[];
  response.responses.forEach((r,i)=>{
    if(!r.success){
      const code=r.error && r.error.code || '';
      if(code.includes('registration-token-not-registered') || code.includes('invalid-registration-token')) invalid.push(unique[i]);
    }
  });
  if(invalid.length){
    const batch=db.batch();
    driversSnap.forEach(d=>{
      const data=d.data()||{}; const updates={};
      for(const t of invalid){ if(data.fcmTokens && data.fcmTokens[t]!==undefined) updates[`fcmTokens.${t}`]=null; if(data.fcmToken===t) updates.fcmToken=null; }
      if(Object.keys(updates).length) batch.update(d.ref,updates);
    });
    await batch.commit();
  }
});

// Same dispatch for the legacy singular collection used by older customer flows.
exports.dispatchNewRideToOnlineDriversLegacy = onDocumentCreated('booking/{bookingId}', async (event) => {
  const snap=event.data; if(!snap) return;
  const b=snap.data()||{};
  const status=String(b.status || '').toLowerCase();
  if(['accepted','assigned','started','ongoing','completed','cancelled','canceled'].includes(status)) return;
  const ds=await db.collection('drivers').where('isOnline','==',true).where('rideEligible','==',true).get();
  const tokens=[];
  ds.forEach(d=>{const x=d.data()||{}; if(String(x.approvalStatus||x.status||'Approved').toLowerCase()!=='approved')return; if(x.fcmToken)tokens.push(x.fcmToken); if(x.fcmTokens)Object.entries(x.fcmTokens).forEach(([t,v])=>v&&tokens.push(t));});
  const unique=[...new Set(tokens)]; if(!unique.length)return;
  await getMessaging().sendEachForMulticast({tokens:unique,notification:{title:'Darshana Sethu – New Ride',body:bookingText(b)},data:{type:'new_ride',bookingId:event.params.bookingId},webpush:{headers:{Urgency:'high'},notification:{title:'Darshana Sethu – New Ride',body:bookingText(b),requireInteraction:true}}});
});
